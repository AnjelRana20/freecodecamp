Hello,

Thank you for downloading BLACK PINK.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link info to purchase full version and commercial license: 
BEHANCE: https://www.behance.net/gallery/99955973/Black-Pink-Handwritten-Font

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
etzamnar@gmail.com

- Any donation are very appreciated. Paypal account for donation : paypal.me/axelzone 

Please visit my portfolios to stay tune for my amazing fonts : 
https://www.behance.net/axelzone

Follow our instagram for update : @axelzonestudio

Thank you.